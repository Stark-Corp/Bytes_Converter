This is a **Python library** which Converts **Digital Storage** Units Like **KB** [KiloByte], **MB** [MegaByte] etc. into each or the Other very Efficiently with must Precision and Efficiency.

It has one **Class**, which is:

Class **UnitConversion**: 

```
This Module is the Subpackage of the library which does the work and will convert the Digital Units. kotha bolna
Usage: from Bytes_Converter import UnitConversion as uc
# Say, you will convert from GB to MB 
uc.gb_to_mb(196)

Note: It will return None if bound to a variable. The input should be given in <class 'int'> or <class 'float'>. 
TypeError will be raised if any other data type is used as input, if you use any good text editor like VS Code or any IDE it will show the references while you call the method/function. 
 
```
